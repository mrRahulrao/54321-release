# 54321-release — AI DevOps Engineer Scaffold

This repo is a starter for a prompt-driven Infra GitOps flow on **Azure** with guardrails.

## Quick start
1) **Create SSH key (DO THIS LOCALLY; never share private key)**
   - Linux/macOS:
     ```bash
     ssh-keygen -t ed25519 -C "rahul@laptop" -f ~/.ssh/rahul_54321_ed25519
     chmod 600 ~/.ssh/rahul_54321_ed25519
     ```
   - Windows (PowerShell 7+):
     ```powershell
     ssh-keygen -t ed25519 -C "rahul@laptop" -f $env:USERPROFILE\.ssh\rahul_54321_ed25519
     icacls $env:USERPROFILE\.ssh\rahul_54321_ed25519 /inheritance:r /grant:r "$($env:USERNAME):(R)"
     ```
   - **Never paste your private key anywhere.** Use the `.pub` file in Terraform (`admin_ssh_key.public_key`).

2) **Bootstrap Terraform state backend (one per tenant)**
   - Login and set subscription (replace placeholders):
     ```bash
     az login
     az account set --subscription <SUBSCRIPTION_ID_DEV>
     az group create -n rg-tfstate-54321 -l southeastasia
     az storage account create -n tfstate54321 -g rg-tfstate-54321 -l southeastasia --sku Standard_LRS --kind StorageV2 --allow-blob-public-access false
     az storage container create --name state --account-name tfstate54321
     ```

3) **Create service connections** (Azure DevOps or GitHub OIDC) with least-privilege per subscription.

4) **Run the Generate pipeline** with a prompt. It writes `envs/<env>/prompt.tfvars.json` and opens a PR.
   - PR gates: Terraform plan, OPA/Conftest, tfsec/Checkov, Infracost.
   - Merge → Apply.

## Placeholders to replace
- `SUBSCRIPTION_ID_DEV`, `SUBSCRIPTION_ID_STAGE`, `SUBSCRIPTION_ID_PROD`
- Storage account name if you choose a different one
- Approver(s) in pipeline env protection

## Ring policy (default)
- **Ring 0 (auto):** VM resize ≤ 16 vCPU, disk add ≤ 512 GiB, tags, AKS node count ±1 (private-only)
- **Ring 1 (review):** new AKS/VNet, GPU SKUs, public IP
- **Ring 2 (window):** peering, cross-subscription, major DB changes

## Security defaults
- Region allowlist: `southeastasia`
- Required tags: `env`, `owner`, `costcenter`, `system=appraps`
- Public IP denied in prod unless `approved=true`
